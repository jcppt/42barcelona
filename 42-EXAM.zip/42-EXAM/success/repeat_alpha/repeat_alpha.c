/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   repeat_alpha.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 11:44:34 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/08 12:08:54 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	repeat_alpha(char *str)
{
	int i;
	int c;
	int j;
	
	c = 0;
	i = 0;
	while(str[i])
	{
		if(str[i] >= 'a' && str[i] <= 'z')
		{
			c = str[i] - 'a';
			j = 0;
			while(j <= c)
			{
				write(1, &str[i], 1);
				j++;
			}
		}
		else if(str[i] >= 'A' && str[i] <= 'Z')
		{
			c = str[i] - 'A';
			j = 0;
			while(j <= c)
			{
				write(1, &str[i], 1);
				j++;
			}
		}
		else
			write(1, &str[i], 1);
		i++;
	}
}

int	main(int argc, char **argv)
{
	if(argc == 2)
		repeat_alpha(argv[1]);
	write(1, "\n", 1);
	return(0);
}
