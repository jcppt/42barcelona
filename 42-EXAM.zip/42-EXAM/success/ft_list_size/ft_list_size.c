/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_size.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/09 08:56:51 by pamanzan          #+#    #+#             */
/*   Updated: 2024/08/09 08:59:28 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

typedef struct	s_list
{
	struct s_list	*next;
	void			*data;
}					t_list;

int	ft_list_size(t_list *begin_list)
{
	int i;

	i = 0;
	if (begin_list == 0)
	{
		i = 0;
		return (i);
	}	
	else
		while (begin_list)
		{
			begin_list = begin_list->next;
			i++;
		}
	return (i);
}
