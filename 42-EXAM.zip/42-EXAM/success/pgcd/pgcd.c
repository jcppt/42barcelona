/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pgcd.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 08:08:23 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/08 08:14:53 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void	pgcd(int nb1, int nb2)
{
	if(nb1 > 0 && nb2 >0)
	{
		while(nb1 != nb2)
		{
			if(nb1 > nb2)
				nb1 -= nb2;
			else
				nb2 -= nb1;
		}
		printf("%d", nb1);
	}
}

int main(int argc, char **argv)
{
	if(argc == 3)
		pgcd(atoi(argv[1]), atoi(argv[2]));
	printf("\n");
	return(0);
}
