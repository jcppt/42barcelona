/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   add_prime_sum.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/07 08:15:55 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/07 08:38:27 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_atoi(char *str)
{
	int i;
	int num;

	num = 0;
	i = 0;
	while(str[i])
	{
		num = num * 10 + (str[i] - '0');
		i++;
	}
	return(num);
}

void	write_nbr(int nbr)
{
	char c[10] = "0123456789";

	if(nbr > 9)
		write_nbr(nbr / 10);
	write(1, &c[nbr % 10], 1);
}

int	is_prime(int nbr)
{
	int i;

	if(nbr == 1 || nbr == 0)
		return(0);
	if(nbr % 2 == 0 && nbr > 2)
		return(0);
	i = 3;
	while(i * i / nbr == 0)
	{
		if(nbr % i == 0)
			return (0);
		i += 2;
	}
	return(1);		
}

void	add_prime_sum(int nbr)
{
	int i;
	int sum;

	sum = 0;
	i = 2;
	while (i <= nbr)
	{
		if(is_prime(i))
			sum = sum + i;
		i++;
	}
	write_nbr(sum);
}

int	main(int argc, char **argv)
{
	if(argc == 2 && ft_atoi(argv[1]) >= 0)
	{
		add_prime_sum(ft_atoi(argv[1]));
		write(1, "\n", 1);
	}
	else
	{
		write_nbr(0);
		write(1, "\n", 1);
	}
}
