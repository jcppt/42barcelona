/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   alpha_mirror.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/07 07:25:47 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/07 08:03:04 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	alpha_mirror(char *str)
{
	int i;
	char c;

	i = 0;
	while(str[i])
	{
		c = str[i];
		if(str[i] >= 'a' && str[i] <= 'z')
			c = 'z' - str[i] + 'a';
		else if(str[i] >= 'A' && str[i] <= 'Z')
			c = 'Z' - str[i] + 'A';
		write(1, &c, 1);
		i++;
	}
}

int	main(int argc, char **argv)
{
	if(argc == 2)
		alpha_mirror(argv[1]);
	write(1, "\n", 1);
	return(0);
}
