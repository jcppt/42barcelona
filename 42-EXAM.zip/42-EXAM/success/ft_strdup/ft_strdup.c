/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/07 08:26:18 by pamanzan          #+#    #+#             */
/*   Updated: 2024/08/07 08:43:39 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *src)
{
	int i;

	i = 0;
	while(src[i])
		i++;
	return(i);
}

char	*ft_strdup(char *src)
{
	int i;
	char *copy;

	copy = malloc(ft_strlen((char *)src) +  1);
	if (copy != NULL)
	{
		i = 0;
		while(src[i])
		{
			copy[i] = src[i];
			i++;
		}
		copy[i] = '\0';
		return(copy);
	}
	return(copy);
}
