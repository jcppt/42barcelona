/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/07 10:14:19 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/07 10:32:39 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int ft_atoi(const char *str)
{
	int i;
	int sign;
	int num;

	num = 0;
	sign = 1;
	i = 0;
	while(str[i] ==  32 || (str[i] >= 9 && str[i] <= 13))
		i++;
	if(str[i] == '-')
	{
		sign = -1;
		i++;
	}
	if(str[i] == '+')
		i++;
	while(str[i] >= '0' && str[i] <= '9')
	{
		num = num * 10 + (str[i] - '0');
		i++;
	}
	return(sign * num);
}
