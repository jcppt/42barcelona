/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   str_capitalizer.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 10:30:12 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/08 11:13:26 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	str_capitalizer(char *str)
{
	int i;
	char c;

	if(str[0] >= 'a' && str[0] <= 'z')
		c = str[0] - 32;
	else
		c = str[0];
	write(1, &c, 1);
	i = 1;
	while(str[i])
	{
		c = str[i];
		if(str[i] >= 'A' && str[i] <= 'Z')
			c = str[i] + 32;
		if(str[i - 1] == 32 || (str[i - 1] == 9 && str[i - 1] == 13))
		{
			if(str[i] >= 'a' && str[i] <= 'z')
				c = str[i] - 32;
			else if(str[i] >= 'A' && str[i] <= 'z')
				c = str[i];
		}
		write(1, &c, 1);
		i++;
	}
}

int main(int argc, char **argv)
{
	int i;

	i = 2;
	if(argc == 1)
		write(1, "\n", 1);
	while(i <= argc)
	{
		str_capitalizer(argv[i - 1]);
		write(1, "\n", 1);
		i++;
	}
	return(0);
}
