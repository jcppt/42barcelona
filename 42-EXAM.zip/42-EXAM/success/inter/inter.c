/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   inter.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/07 11:13:24 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/07 13:10:35 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int has_char(char *str, char c)
{
	int i = 0;
    while (str[i])
    {
        if (str[i] == c)
            return 1;
        i++;
    }
    return 0;
}

/*void	ft_putstr(char *str)
{
	int i = 0;
	while(str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}*/

void inter(char *str1, char *str2)
{
    char printed[128];
	char word;
    int i = 0;
	int j = 0;

    while (str1[j])
    {
		if(has_char(str1, str1[j]))
			word = str1[j];
        if (has_char(str2, word) && !has_char(printed, word))
        {
            write(1, &str1[j], 1);
            printed[i] = str1[j];
            i++;
        }
        j++;
    }

}

int	main(int argc, char **argv)
{
	if(argc == 3)		
		inter(argv[1], argv[2]);
	write(1, "\n", 1);
	return(0);
}
