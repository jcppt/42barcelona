/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/10 08:18:57 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/10 08:26:27 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stddef.h>

int	*ft_range(int start, int end)
{
	int i;
	int *tab;
	int len;

	len = abs(end - start) + 1;
	tab = (int *)malloc(sizeof(int) * len);
	i = 0;
	while(i < len)
	{
		if(start < end)
		{
			tab[i] = start;
			++start;
			i++;
		}
		else
		{
			tab[i] = start;
			start--;
			i++;
		}
	}
	return(tab);
}

