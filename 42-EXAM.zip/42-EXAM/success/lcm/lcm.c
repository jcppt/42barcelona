/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lcm.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/04 14:41:08 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/04 14:55:01 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

unsigned int	mcm_hcf(unsigned int a, unsigned int b)
{
	unsigned int temp;

	while(b != 0)
	{
		temp = b;
		b = a % b;
		a = temp;
	}
	return (a);
}

unsigned int lcm(unsigned int a, unsigned int b)
{
	int inta = a;
	int intb = b;

	if(inta <= 0 || intb <= 0)
		return(0);
	return((abs(inta) / mcm_hcf(a, b)) * abs(intb));
}
