/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   first_word.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/10 10:11:56 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/10 10:20:57 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	first_word(char *str)
{
	int i;
	i = 0;

	while(str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
		i++;
	while(!(str[i] == 32 || (str[i] >= 9 && str[i] <= 13)) && str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}

int main(int argc, char **argv)
{
	if(argc == 2)
		first_word(argv[1]);
	write(1, "\n", 1);
	return(0);
}
