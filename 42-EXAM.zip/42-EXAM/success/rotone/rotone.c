/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rotone.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/09 08:31:43 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/09 08:39:03 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	rotone(char *str)
{
	int i;
	char c;

	i = 0;
	while(str[i])
	{
		c = str[i];
		if((str[i] >= 'a' && str[i] <= 'y') || (str[i] >= 'A' && str[i] <= 'Y')) 					c = str[i] + 1;
		else if(str[i] == 'z')
			c = 'a';
		else if(str[i] == 'Z')
			c = 'A';		
		write(1, &c, 1);
		i++;
	}
}

int	main(int argc, char **argv)
{
	if(argc == 2)
		rotone(argv[1]);
	write(1, "\n", 1);
	return(0);
}
