/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   snake_to_camel.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/05 08:36:32 by pamanzan          #+#    #+#             */
/*   Updated: 2024/08/05 09:08:08 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	snake_to_camel(char *str)
{
	int i;
	char c;

	i = 0;
	while(str[i] != '\0')
	{
		if(str[i] == '_')
		{
			c = str[i + 1] - 32;
			i++;
		}
		else if(str[i] == '_')
			i++;
		else
			c = str[i];
		write(1, &c, 1);
		i++;
	}
}

int	main(int argc, char **argv)
{
	if(argc == 2)
		snake_to_camel(argv[1]);
	write(1, "\n", 1);
	return(0);
}
