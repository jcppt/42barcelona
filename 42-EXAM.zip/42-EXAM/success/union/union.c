/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   union.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/05 07:58:52 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/05 08:46:32 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	saved_char(char *str, char c)
{
	int i;

	i = 0;
	while(str[i])
	{
		if(str[i] == c)
			return(1);
		i++;
	}
	return(0);
}

void	ft_union(char *s1, char *s2)
{
	int i;
	int j;
	int k;
	char str[1000];

	i = 0;
	j = 0;
	while(s1[i])
	{
		if(!saved_char(str, s1[i]))
		{
			str[j] = s1[i];
			write(1, &s1[i], 1);
			j++;
		}
		i++;
	}
	k = 0;
	while(s2[k])
	{
		if(!saved_char(str, s2[k]))
		{
			str[j] = s2[k];
			write(1, &s2[k], 1);
			j++;
		}
		k++;
	}
	
}

int main(int argc, char **argv)
{
	if(argc != 3)
		write(1, "\n", 1);
	ft_union(argv[1], argv[2]);
	write(1, "\n", 1);
	return(0);
}
