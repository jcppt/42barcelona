/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rostring.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/10 08:29:53 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/10 09:18:46 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int i;

	i = 0;
	while(str[i])
		i++;
	return(i);
}

void	ft_putstr(char *str)
{
	int i;

	i = 0;
	while(str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}

void	rostring(char *str)
{
	int i;
	int j;
	int len;
	char *word;

	len = ft_strlen(str) - 1;
	word = (char *)malloc(sizeof(char) * 100);
	i = 0;
	while(str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
		i++;
	while(str[len] == 32 || (str[len] >= 9 && str[len] <= 13))
		len--;
	j = 0;
	while(str[i] && !(str[i] == 32 || (str[i] >= 9 && str[i] <= 13)))
	{
		word[j] = str[i];
		j++;
		i++;
	}
	word[j] = '\0';
	while(str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
		i++;
	if(i <= len)
		write(1, &str[i], 1);
	i++;
	while(i <= len && str[i])
	{
		while(str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
			i++;
		if(str[i - 1] == 32 || (str[i - 1] >= 9 && str[i - 1] <= 13))
			write(1, " ", 1);
		write(1, &str[i], 1);
		if(i == len)
			write(1, " ", 1);
		i++;
	}
	ft_putstr(word);
	free(word);
}

int main(int argc, char **argv)
{
	if(argc >= 2)
		rostring(argv[1]);
	write(1, "\n", 1);
	return(0);
}
