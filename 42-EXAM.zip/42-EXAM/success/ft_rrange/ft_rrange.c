/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rrange.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/04 11:55:49 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/04 11:57:41 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdlib.h>

int	*ft_rrange(int start, int end)
{
	int len;
	int i = 0;
	int *tab;

	len = abs(end - start) + 1;
	tab = (int *)malloc(sizeof(int) * len);
	while(i < len)
	{
		if(start > end)
		{
			tab[i] = end;
			end++;
			i++;
		}
		else
		{
			tab[i] = end;
			end--;
			i++;
		}
	}
	return(tab);
}
