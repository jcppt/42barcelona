/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   do_op.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/04 07:59:49 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/04 08:23:35 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

void	do_op(int n1, char op, int n2)
{
	int result;

	result = 0;
	if(op == 37)
		result = n1 % n2;
	else if(op == 42)
		result = n1 * n2;
	else if(op == 43)
		result = n1 + n2;
	else if(op == 45)
		result = n1 - n2;
	else if(op == 47)
		result = n1 / n2;
	printf("%d", result);
}

int	main(int argc, char **argv)
{
	if(argc == 4)
		do_op(atoi(argv[1]), *argv[2], atoi(argv[3]));
	printf("\n");
	return(0);
}
