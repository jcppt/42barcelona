/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   last_word.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/10 10:22:22 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/10 10:37:16 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int	i;
	
	i = 0;
	while(str[i])
		i++;
	return(i);
}

void	last_word(char *str)
{
	int len;
	
	len = ft_strlen(str) - 1;

	while((str[len] == 32 || (str[len] >= 9 && str[len] <= 13)) && str[len] > 0)
		len--;
	while(!(str[len] == 32 || (str[len] >= 9 && str[len] <= 13)) && str[len] > 0)
		len--;
	if((str[len] == 32 || (str[len] >= 9 && str[len] <= 13)) && str[len] > 0)
		len++;
	while(!(str[len] == 32 || (str[len] >= 9 && str[len] <= 13)) && str[len])
	{
		write(1, &str[len], 1);
		len++;
	}
}

int main(int argc, char **argv)
{
	if(argc == 2)
		last_word(argv[1]);
	write(1, "\n", 1);
	return(0);
}

