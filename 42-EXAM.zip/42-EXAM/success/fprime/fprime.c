/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fprime.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/03 09:41:57 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/03 09:53:07 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int ft_is_prime(int nb)
{
	int i;

	if(nb == 1 || nb == 0)
		return(0);
	if(nb % 2 == 0 && nb > 2)
		return(0);
	i = 3;
	while(i * i / nb <= 0)
	{
		if(nb % i == 0)
			return(0);
		i += 2;
	}
	return(1);
}

void fprime(int nb)
{
	int i;
	int start;

	i = 0;
	start = 0;

	if(nb == 1)
		printf("%d", nb);
	while(i <= nb)
	{
		if(ft_is_prime(i))
		{
			while(nb % i == 0)
			{
				if(start != '\0')
					printf("*");
				start++;
				nb = nb / i;
				printf("%d", i);
			}
		}
		i++;
	}
}

int	main(int argc, char **argv)
{
	if(argc == 2)
		fprime(atoi(argv[1]));
	printf("\n");
	return(0);
}
