/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rev_print.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/03 10:09:09 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/03 10:19:06 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int i;

	i = 0;
	while(str[i])
		i++;
	return(i);
}

void	rev_print(char *str)
{
	int i;
	int len;

	len = ft_strlen(str) - 1;
	i = 0;
	while(len >= 0)
	{
		write(1, &str[len], 1);
		len--;
	}
}

int	main(int argc, char **argv)
{
	if(argc == 2)
		rev_print(argv[1]);
	write(1, "\n", 1);
	return(0);
}
