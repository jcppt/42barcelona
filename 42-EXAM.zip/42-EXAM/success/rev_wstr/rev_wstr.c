/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rev_wstr.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/02 15:00:41 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/02 16:01:38 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int ft_strlen(char *str)
{
	int i;

	i = 0;
	while(str[i] != '\0')
		i++;
	return(i);
}

void	rev_wstr(char *str)
{
	int i;
	int f;
	int len;
	int first_word;

	len = ft_strlen(str) - 1;
	first_word = 1;

	while (len >= 0)
	{
		f = len;
		while (len >= 0 && str[len] != ' ')
			len--;
		i = len + 1;
		if (!first_word)
			write(1, " ", 1);
		while (i <= f)
		{
			write(1, &str[i], 1);
			i++;
		}
		first_word = 0;
		len--;
	}
}

int main(int argc, char **argv)
{
	if(argc == 2)
		rev_wstr(argv[1]);
	write(1, "\n", 1);
	return(0);
}
