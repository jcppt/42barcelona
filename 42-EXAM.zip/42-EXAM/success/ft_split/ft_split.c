/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 08:40:33 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/08 08:57:28 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int ft_strlen(char *str)
{
	int i;

	i = 0;
	while(str[i])
		i++;
	return(i);
}

char	*save_word(char *str, int *cont)
{
	int i;
	char *word;

	i = 0;
	word = (char *)malloc(sizeof(char) * 100);
	while(!(str[*cont] == 32 || (str[*cont] >= 9 && str[*cont] <= 13)) && str[*cont])
	{
		word[i] = str[*cont];
		*cont += 1;
		i++;
	}
	word[i] = '\0';
	return(word);
}

char	**ft_split(char *str)
{
	int i;
	int k;
	char **big_box;
	int len;

	len = ft_strlen(str) - 1;
	i = 0;
	k = 0;
	while((str[i] == 32 || (str[i] >= 9 && str[i] <= 13)) && str[i])
		i++;
	while((str[len] == 32 || (str[len] >= 9 && str[len] <= 13)) && str[i])
		len--;
	big_box = (char **)malloc(sizeof(char *) * 1000);
	while(i <= len)
	{
		while((str[i] == 32 || (str[i] >= 9 && str[i] <= 13)))
			i++;
		big_box[k] = save_word(str, &i);
		k++;
		i++;	
	}
	big_box[k] = NULL;
	return(big_box);
}
