 [/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tab_mult.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/10 10:39:36 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/10 11:09:13 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_atoi(char *str)
{
	int i;
	int sign;
	int num;

	num = 0;
	sign = -1;
	i = 0;
	if(str[i] == '-')
		i++;
	else
		sign = 1;
	while(str[i] >= '0' && str[i] <= '9')
	{
		num = num * 10 + (str[i] - '0');
		i++;
	}
	return(num * sign);
	
}

void	write_nbr(int nbr)
{
	char c[10] = "0123456789";

	if(nbr > 9)
		write_nbr(nbr / 10);
	write(1, &c[nbr % 10], 1);
}

void	tab_mult(int nbr)
{
	int i;
	int result;

	result = 0;
	i = 1;
	while(i <= 9)
	{
		write_nbr(i);
		write(1, " x ", 3);
		write_nbr(nbr);
		write(1, " = ", 3);
		result = i * nbr;
		write_nbr(result);
		if(i < 9)
			write(1, "\n", 1);
		i++;
	}
}

int main(int argc, char **argv)
{
	if(argc == 2 && ft_atoi(argv[1]) >= 0)
		tab_mult(ft_atoi(argv[1]));
	write(1, "\n", 1);
	return(0);
}


