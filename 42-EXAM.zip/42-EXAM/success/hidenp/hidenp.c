/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hidenp.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/07 12:07:40 by pamanzan          #+#    #+#             */
/*   Updated: 2024/08/07 13:38:49 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int ft_strlen(char *str)
{
	int i;

	i = 0;
	while(str[i])
		i++;
	return(i);
}

void hidenp(char *s1, char *s2)
{
	int i;
	int j;
	int k;

	i = 0;
	j = 0;
	while(s1[i] && s2[j])
	{
		if(s2[j] == s1[i])
		{
			i++;
		}
		j++;	
	}
	if (ft_strlen(s1) == i)
		write (1, "1", 1);
	else
		write(1, "0", 1);
}

int main(int argc, char **argv)
{
	if(argc == 3)
		hidenp(argv[1], argv[2]);
	write(1, "\n", 1);
	return(0);
}
