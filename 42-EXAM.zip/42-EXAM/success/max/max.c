/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   max.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/08 12:11:34 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/08 12:21:50 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	max(int* tab, unsigned int len)
{
	int i;
	int c;

	i = 0;
	if(len == 0)
		return(0);
	c = tab[0];
	while(i <= len)
	{
		if(c < tab[i])
			c = tab[i];
		i++;
	}
	return(c);
}
