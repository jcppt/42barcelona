/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_list.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/10 11:38:08 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/10 12:10:01 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "list.h"
#include <stddef.h>

t_list *sort_list(t_list* lst, int (*cmp)(int, int))
{
	int *temp;
	int swap;

	temp = lst;
	while(lst->next != NULL)
	{	
		if(((*cmp)(lst->data,lst->next->data)) == 0)
		{
			swap = lst->data;
			lst->data = lst->next->data;
			lst->next->data = swap;
			lst = temp;
		}
		else
			lst = lst->next;
	}
	lst = temp;
	return(lst);
}

/*int main()
{
	t_list *resultado;
	int i = 0;

	resultado = malloc(sizeof(t_list) * 100);
	while(i < 100)
	{
		resultado[i]->data = 100 - i;
		if(i == 99)
			resultado[i]->next = NULL;
		else
			resultado[i]->next = &resultado[i + 1];		
	}
	
}*/
