/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   paramsum.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pamanzan <pamanzan@student.42barcelon      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/06 09:30:06 by pamanzan          #+#    #+#             */
/*   Updated: 2024/09/06 09:36:27 by pamanzan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	write_nbr(int nbr)
{
	char c[10] = "0123456789";

	if(nbr > 9)
		write_nbr(nbr / 10);
	write(1, &c[nbr % 10], 1);
}

int main(int argc, char **argv)
{
	if(!**argv)
		write_nbr(0);
	write_nbr(argc - 1);
	write(1, "\n", 1);
	return(0);
}
